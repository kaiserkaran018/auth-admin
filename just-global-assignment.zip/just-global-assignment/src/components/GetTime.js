// src/components/GetTime.js
import React, { useEffect, useState } from "react";

import { apiURL } from "../lib/constants/index";
import { ApiRoutes } from "../lib/apiRoutes/index";

const { time } = ApiRoutes;

export function GetTime() {
  const [timer, setTimer] = useState(null);

  useEffect(() => {
    const fetchTime = async () => {
      const token = localStorage.getItem("token");
      try {
        const response = await fetch(`${apiURL}${time}`, {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        const data = await response.json();
        if (response.ok) {
          setTimer(data.time);
        } else {
          alert(data.error);
        }
      } catch (error) {
        console.error("Error:", error);
      }
    };

    fetchTime();
  }, []);

  const renderTime = () => {
    const d = new Date(timer);
    const date = d.toISOString().split("T")[0];
    const time = d.toTimeString().split(" ")[0];
    return `${date} ${time}`;
  };

  return (
    <div>
      <h2>Current Server Time</h2>
      {timer ? <p>{renderTime()}</p> : <p>Loading...</p>}
    </div>
  );
}
