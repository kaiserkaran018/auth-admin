// src/components/VerifyOTP.js
import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { apiURL } from "../lib/constants";
import { ApiRoutes } from "../lib/apiRoutes";

const { verifyOTP } = ApiRoutes;

export function VerifyOTP() {
  const { token } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    verifyLink();
  }, []);

  const verifyLink = async () => {
    try {
      const response = await fetch(`${apiURL}${verifyOTP}${token}`);
      const data = await response.json();
      if (response.ok) {
        localStorage.setItem("token", data.token);
        navigate("/get-time");
      } else {
        alert(data.error);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };
  return <div>Verifying...</div>;
}
