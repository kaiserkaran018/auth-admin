// src/components/Login.js
import React from "react";
import { useNavigate } from "react-router-dom";

import { apiURL } from "../lib/constants/index";
import { ApiRoutes } from "../lib/apiRoutes/index";

const { insertUser } = ApiRoutes;

export function UserInsert() {
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`${apiURL}${insertUser}`, {
        method: "POST",
        "Referrer-Policy": "origin",
        headers: {
          "Content-Type": "application/json",
        },
      });
      if (response.status === 201) navigate("/");
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <button type="submit">Insert User</button>
      </form>
    </div>
  );
}
