// src/components/RequestOTP.js
import React, { useState } from "react";

import { apiURL } from "../lib/constants/index";
import { ApiRoutes } from "../lib/apiRoutes/index";

const { requestOTP } = ApiRoutes;

export function RequestOTP() {
  const [username, setUsername] = useState("");
  const [link, setLink] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch(`${apiURL}${requestOTP}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username }),
      });
      const data = await response.json();
      if (response.ok) {
        setLink(data.link);
      } else {
        alert(data.error);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <h2>Request One-Time Link</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Username: </label>
          <input
            type="text"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>
        <button type="submit">Request Link</button>
      </form>
      {link && (
        <div>
          <p>Here is your one-time link:</p>
          <a href={link}>{link}</a>
        </div>
      )}
    </div>
  );
}
