CREATE TABLE users (
    id INT NOT NULL PRIMARY KEY,
    username VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    failed_attempts INT NOT NULL DEFAULT 0,
    is_locked INT NOT NULL DEFAULT 0
);


CREATE TABLE tokens (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    token TEXT,
    expiry_date TIMESTAMP,
    is_used INT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id),
    UNIQUE (token(255))
);
