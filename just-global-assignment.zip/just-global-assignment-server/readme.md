## Available Scripts

In the project directory, you can run:

### `node index.js`

Runs the server and db connection will be established.

## create a user on mysql and execute create table query on `create_tables.sql`.

## port will be served on 3000

# Routes

admin -> where kickout api will be executed without any validations.

auth -> where login, request otp, verify otp and time api calls will be executed

seed -> to seed sample users on initial boot,
