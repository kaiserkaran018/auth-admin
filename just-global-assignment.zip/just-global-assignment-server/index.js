// index.js
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const mysql = require("mysql2");

const app = express();

const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(cors());

// Middleware
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: "localhost",
  user: "karan",
  password: "Pass@1",
  database: "testDB",
});

db.connect((err) => {
  if (err) {
    console.error("Error connecting to MySQL:", err);
    return;
  }
  console.log("Connected to MySQL");
});

// Routes
const authRouter = require("./routes/auth");
const adminRouter = require("./routes/admin");
const seeder = require("./routes/seed");

app.use("/auth", authRouter);
app.use("/admin", adminRouter);
app.use("/seed", seeder);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
