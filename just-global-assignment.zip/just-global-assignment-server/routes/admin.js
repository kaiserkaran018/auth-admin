const express = require("express");
const router = express.Router();
const mysql = require("mysql2");

// Connecting db
const db = mysql.createConnection({
  host: "localhost",
  user: "karan",
  password: "Pass@1",
  database: "testDB",
});

// Kickout API
router.post("/kickout", (req, res) => {
  const { username } = req.body;

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (err, user) => {
      if (err || !user)
        return res.status(404).json({ status: 404, error: "User not found" });

      db.query("DELETE FROM tokens WHERE user_id = ?", [user.id], (err) => {
        if (err)
          return res
            .status(500)
            .json({ status: 500, error: "Could not kick out user" });
        res.json({ status: 200, message: "User kicked out successfully" });
      });
    }
  );
});

module.exports = router;
