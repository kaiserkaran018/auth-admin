const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const Bodyparser = require("body-parser");
const express = require("express");

const router = express.Router();

// body parser
const urlencoded = Bodyparser.json({ extended: true });

// sample users
const users = [
  { username: "user1@example.com", password: "password1" },
  { username: "user2@example.com", password: "password2" },
];

// Connecting db
const db = mysql.createConnection({
  host: "localhost",
  user: "karan",
  password: "Pass@1",
  database: "testDB",
});

router.post("/insert/user", urlencoded, (req, res) => {
  users.forEach((user) => {
    bcrypt.hash(user.password, 10, (err, hash) => {
      const id = Number(Math.floor(Math.random() * 1000000 + 1));
      if (err) throw err;
      db.query("INSERT INTO users (id, username, password) VALUES (?, ?, ?)", [
        id,
        user.username,
        hash,
      ]);
    });
  });
  return res.status(201).json({ status: 201, message: "Sample Users Created" });
});

module.exports = router;
