const express = require("express");
const router = express.Router();
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const rateLimit = require("express-rate-limit");
const { v4: uuidv4 } = require("uuid");

// Connecting db
const db = mysql.createConnection({
  host: "localhost",
  user: "karan",
  password: "Pass@1",
  database: "testDB",
});

// Rate limiting
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // limit each IP to 5 requests per windowMs
  message: "Too many login attempts from this IP, please try again later.",
});

// JWT Secret
const JWT_SECRET =
  "fe95e94cf9066d52129ee48e6f9811de6d7dfcc11fb21271d86a624b580c20cc";

// Configurations
const ACCOUNT_LOCK_THRESHOLD = 5;
const OTP_LINK_EXPIRY_MINUTES = 10;

// Helper functions
const generateToken = (user) => {
  return jwt.sign({ id: user.id, username: user.username }, JWT_SECRET, {
    expiresIn: "1h",
  });
};

// User Authentication via username/password
router.post("/login", loginLimiter, (req, res) => {
  const { username, password } = req.body;
  db.query(
    "SELECT * FROM users WHERE username = ? LIMIT 1",
    [username],
    (err, users) => {
      const user = users[0];
      console.log(username, err, users, "findmehere");
      if (err || !user) {
        console.log(err, user, "findmehere");
        return res
          .status(401)
          .json({ status: 401, error: "Invalid username or password" });
      }
      if (user.is_locked)
        return res
          .status(403)
          .json({ status: 403, error: "Account is locked" });

      bcrypt.compare(password, user.password, (err, result) => {
        console.log(password, user.password, "findmehere", err, result);
        if (result) {
          const token = generateToken(user);
          res.json({ token });
        } else {
          db.query(
            "UPDATE users SET failed_attempts = failed_attempts + 1 WHERE id = ?",
            [user.id],
            () => {
              if (user.failed_attempts + 1 >= ACCOUNT_LOCK_THRESHOLD) {
                db.query("UPDATE users SET is_locked = 1 WHERE id = ?", [
                  user.id,
                ]);
              }
            }
          );
          res
            .status(401)
            .json({ status: 401, error: "Invalid username or password" });
        }
      });
    }
  );
});

// User Authentication via one-time link
router.post("/request-otp-link", (req, res) => {
  const { username } = req.body;
  const oneTimeToken = uuidv4();
  const expiryDate = new Date(
    new Date().getTime() + OTP_LINK_EXPIRY_MINUTES * 60000
  );

  db.query(
    "SELECT * FROM users WHERE username = ?",
    [username],
    (err, users) => {
      const user = users[0];
      console.log(user, "findmehere");
      if (err || !user)
        return res.status(404).json({ status: 404, error: "User not found" });

      db.query(
        "INSERT INTO tokens (user_id, token, expiry_date) VALUES (?, ?, ?)",
        [user.id, oneTimeToken, expiryDate],
        (err) => {
          if (err)
            return res
              .status(500)
              .json({ status: 500, error: "Could not generate OTP link" });
          res.json({
            status: 200,
            link: `http://localhost:5200/verify-otp/${oneTimeToken}`,
          });
        }
      );
    }
  );
});

router.get("/verify-otp-link/:token", (req, res) => {
  const { token } = req.params;

  console.log(token, "findmehere");

  db.query(
    "SELECT * FROM tokens WHERE token = ? AND expiry_date > ? AND is_used = 0",
    [token, new Date()],
    (err, tokenRecords) => {
      const tokenRecord = tokenRecords[0];
      console.log(err, tokenRecord, tokenRecords, "findmehere");
      if (err || !tokenRecord)
        return res
          .status(400)
          .json({ status: 400, error: "Invalid or expired link" });

      db.query(
        "UPDATE tokens SET is_used = 1 WHERE id = ?",
        [tokenRecord.id],
        () => {
          db.query(
            "SELECT * FROM users WHERE id = ?",
            [tokenRecord.user_id],
            (err, user) => {
              if (err || !user)
                return res
                  .status(404)
                  .json({ status: 404, error: "User not found" });
              const jwtToken = generateToken(user);
              res.json({ token: jwtToken });
            }
          );
        }
      );
    }
  );
});

// Get Time API
router.get("/time", (req, res) => {
  const authHeader = req.headers.authorization;
  console.log(authHeader, "findmehere");
  if (!authHeader)
    return res.status(401).json({ status: 401, error: "Token required" });

  const token = authHeader.split(" ")[1];
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err)
      return res.status(401).json({ status: 401, error: "Invalid token" });
    res.json({ time: new Date() });
  });
});

module.exports = router;
